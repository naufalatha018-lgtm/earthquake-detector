import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:firebase_database/firebase_database.dart';

class GempaProvider extends ChangeNotifier {

  // 🔥 FIREBASE REF (SUDAH SESUAI)
  final DatabaseReference _dbRef =
      FirebaseDatabase.instance.ref("demo_environment/earthquake_data");

  // 🔥 STATE
  double magnitude = 0;
  double distanceKm = 0;
  bool statusTrigger = false;

  Map<String, String> gempa = {
    "tanggal": "-",
    "jam": "-",
    "magnitude": "-",
    "kedalaman": "-",
    "wilayah": "-",
  };

  List<double> magnitudes = [];
  List<Map<String, String>> logs = [];

  final AudioPlayer _player = AudioPlayer();
  bool _isPlaying = false;

  // 🚀 LISTENER
  void startListening() {
    _dbRef.onValue.listen((event) {
      final raw = event.snapshot.value;

      if (raw == null) {
        print("❌ DATA NULL");
        return;
      }

      // ✅ FIX PARSING (AMAN)
      final map = Map<String, dynamic>.from(
        (raw as Map).map((key, value) => MapEntry(key.toString(), value)),
      );

      print("🔥 DATA MASUK: $map");

      // ✅ FIX TYPE
      magnitude = (map['magnitude'] as num?)?.toDouble() ?? 0.0;
      distanceKm = (map['distance_km'] as num?)?.toDouble() ?? 0.0;
      statusTrigger = map['status_trigger'] as bool? ?? false;

      // 🕒 WAKTU
      final now = DateTime.now();

      final tanggal =
          "${now.day.toString().padLeft(2, '0')}-${now.month.toString().padLeft(2, '0')}-${now.year}";

      final jam =
          "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}";

      // 🔄 UI
      gempa = {
        "tanggal": tanggal,
        "jam": jam,
        "magnitude": magnitude.toStringAsFixed(1),
        "kedalaman": "$distanceKm km",
        "wilayah": statusTrigger ? "⚠️ BAHAYA GEMPA" : "AMAN",
      };

      // 📊 CHART
      magnitudes.add(magnitude);
      if (magnitudes.length > 10) {
        magnitudes.removeAt(0);
      }

      // 📜 LOGS
      logs.insert(0, {
        "tanggal": tanggal,
        "jam": jam,
        "magnitude": magnitude.toStringAsFixed(1),
        "kedalaman": "$distanceKm km",
        "wilayah": statusTrigger ? "BAHAYA GEMPA" : "AMAN",
      });

      if (logs.length > 20) {
        logs.removeLast();
      }

      // 🚨 ALARM - HANYA GUNAKAN status_trigger (SINGLE SOURCE OF TRUTH)
      if (statusTrigger) {
        _playAlarm();
      }

      notifyListeners();
    });
  }

  // 🔊 ALARM
  Future<void> _playAlarm() async {
    if (_isPlaying) return;

    _isPlaying = true;
    await _player.play(AssetSource('sounds/alarm.mp3'));

    Future.delayed(const Duration(seconds: 3), () {
      _isPlaying = false;
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}