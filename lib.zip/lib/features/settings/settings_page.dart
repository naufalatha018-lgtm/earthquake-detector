import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  Widget item(BuildContext context, String title, IconData icon, String route) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: () => context.push(route),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Settings"),
        leading: const BackButton(),
      ),
      body: ListView(
        children: [
          item(context, "Account & Access", Icons.person, "/settings/account"),
          item(context, "Hardware & Diagnostics", Icons.memory, "/settings/hardware"),
          item(context, "Alert Parameters", Icons.warning, "/settings/alerts"),
          item(context, "Emergency Protocol", Icons.phone, "/settings/emergency"),
          item(context, "System Preferences", Icons.settings, "/settings/system"),
        ],
      ),
    );
  }
}
