import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: const [
          ListTile(title: Text('Account')),
          ListTile(title: Text('Hardware')),
          ListTile(title: Text('Alerts')),
          ListTile(title: Text('Emergency')),
          ListTile(title: Text('System')),
        ],
      ),
    );
  }
}